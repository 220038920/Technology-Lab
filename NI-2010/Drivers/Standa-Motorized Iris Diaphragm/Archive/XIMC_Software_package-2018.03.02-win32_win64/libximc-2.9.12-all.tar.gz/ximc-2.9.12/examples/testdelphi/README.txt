Eng. To work this example copy files ximc.pas, keyfile.sqlite, libximc.dll, xiwrapper.dll, bindy.dll from ximc folder next to testdelphi.dpr

Ru. Для работы примера скопируйте файлы ximc.pas, keyfile.sqlite, libximc.dll, xiwrapper.dll, bindy.dll из папки ximc рядом с testdelphi.dpr